var firebaseConfig = {
	apiKey: "AIzaSyCBe0cCZGU5VdvgGmtqjUz0QvyaxwKJjfE",
	authDomain: "yuva-baseline-survey.firebaseapp.com",
	databaseURL: "https://yuva-baseline-survey.firebaseio.com",
	projectId: "yuva-baseline-survey",
	storageBucket: "yuva-baseline-survey.appspot.com",
	messagingSenderId: "285927087955",
	appId: "1:285927087955:web:7b209abbcb4230b720cba6"
};